package main

import (
	"log"
	"os"

	"github.com/spf13/viper"
)

type Config struct {
	Port             string `mapstructure:"port"`
	ConnectionString string `mapstructure:"connection_string"`
	AdminUsername    string `mapstructure:"admin_username"`
	AdminPassword    string `mapstructure:"admin_password"`
}

var AppConfig *Config

func LoadAppConfig() {

	ConnectionString := os.Getenv("CONNECTION_STRING")
	port := os.Getenv("PORT")
	if port == "" {
		port = "80"
	}

	adminUsername := os.Getenv("ADMIN_USERNAME")
	if adminUsername == "" {
		log.Fatal("no admin username specified")
	}

	adminPassword := os.Getenv("ADMIN_PASSWORD")
	if adminPassword == "" {
		log.Fatal("no admin password specified")
	}

	if ConnectionString == "" {
		log.Println("Loading Server Configurations...")
		viper.AddConfigPath(".")
		viper.SetConfigName("config")
		viper.SetConfigType("json")
		err := viper.ReadInConfig()
		if err != nil {
			log.Fatal(err)
		}
		err = viper.Unmarshal(&AppConfig)
		if err != nil {
			log.Fatal(err)
		}
	} else {
		AppConfig = &Config{
			ConnectionString: ConnectionString,
			Port:             port,
			AdminUsername:    adminUsername,
			AdminPassword:    adminPassword,
		}
	}
}
