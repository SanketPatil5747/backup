package entities

type JobBand struct {
	ID           int    `json:"id"`
	Name         string `json:"name"`
	DisplayOrder int    `json:"DisplayOrder"`
}
