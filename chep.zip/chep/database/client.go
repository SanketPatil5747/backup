package database

import (
	"log"
	"whartonbc-chep/entities"

	"gorm.io/driver/postgres"
	"gorm.io/gorm"
)

var Instance *gorm.DB
var err error

func Connect(connectionString string) {
	log.Println(connectionString)
	Instance, err = gorm.Open(postgres.Open(connectionString), &gorm.Config{})
	if err != nil {
		log.Println(err)
		panic("Cannot connect to DB")
	}
	log.Println("Connected to Database...")
}

func Migrate() {
	err := Instance.AutoMigrate(&entities.JobFamily{}, &entities.JobBand{}, &entities.Question{}, &entities.Competency{}, &entities.Training{}, &entities.JobFunction{})
	if err != nil {
		log.Println(err)
		panic("Database Migration Failed")
	}
	log.Println("Database Migration Completed...")
}
