package controllers

import (
	"html/template"
	"net/http"
	"whartonbc-chep/database"
)

var templates *template.Template

func Init(t *template.Template) {
	templates = t
}

func IndexPage(w http.ResponseWriter, r *http.Request) {
	err := r.ParseForm()
	if err != nil {
		return
	}
	JobFunction := r.Form["JobFunction"]
	data := make(map[string]interface{})
	if len(JobFunction) != 0 && database.CheckIfJobFunctionExists(JobFunction[0]) {

		familys := database.GetJobFamilyies()
		bands := database.GetJobBands()

		data["families"] = familys
		data["bands"] = bands

		err = templates.ExecuteTemplate(w, "index.html", data)
		if err != nil {
			return
		}
	} else {
		functions := database.GetJobFunctions()

		data["functions"] = functions

		err = templates.ExecuteTemplate(w, "index.html", data)
		if err != nil {
			return
		}
	}
}
