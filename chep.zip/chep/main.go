package main

import (
	"fmt"
	"github.com/gorilla/mux"
	"gorm.io/gorm"
	"html/template"
	"log"
	"net/http"
	"os"
	"whartonbc-chep/controllers"
	"whartonbc-chep/database"
	"whartonbc-chep/middleware"
)

var DB *gorm.DB

var templates *template.Template

func main() {

	// Load Configurations from config.json using Viper
	LoadAppConfig()

	// Initialize Database
	database.Connect(AppConfig.ConnectionString)
	database.Migrate()

	// Initialize the router
	router := mux.NewRouter().StrictSlash(true)

	templates = template.Must(templates.ParseGlob("templates/*.html"))
	controllers.Init(templates)

	// Register Routes
	RegisterRoutes(router)

	// Start the server
	log.Println(fmt.Sprintf("Starting Server on port %s...", AppConfig.Port))

	hostname, err := os.Hostname()
	if err != nil {
		fmt.Println(err)
	}
	log.Printf("Running on Hostname: %s\n", hostname)

	log.Fatal(http.ListenAndServe(fmt.Sprintf("0.0.0.0:%v", AppConfig.Port), router))
}

func RegisterRoutes(router *mux.Router) {

	router.HandleFunc("/", controllers.IndexPage).Methods("GET")
	router.HandleFunc("/", controllers.IndexPage).Methods("POST")

	router.HandleFunc("/admin", middleware.BasicAuth(controllers.AdminPage)).Methods("GET")
	router.HandleFunc("/admin", middleware.BasicAuth(controllers.AdminPage)).Methods("POST")
	router.HandleFunc("/admin/download", middleware.BasicAuth(controllers.DownloadTableAsCSV)).Methods("GET")
	router.HandleFunc("/admin/upload", middleware.BasicAuth(controllers.ProcessCSVUploads)).Methods("POST")

	router.HandleFunc("/questions", controllers.QuestionsPage).Methods("POST")
	router.HandleFunc("/questions", controllers.QuestionsPage).Methods("GET")

	router.HandleFunc("/results", controllers.ResultsPageV2).Methods("POST")
	router.HandleFunc("/results", controllers.ResultsPage).Methods("GET")

	router.PathPrefix("/static/").Handler(http.StripPrefix("/static/", http.FileServer(http.Dir("static/"))))

	http.Handle("/", router)
}
