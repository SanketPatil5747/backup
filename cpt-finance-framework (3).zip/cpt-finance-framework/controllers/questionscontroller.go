package controllers

import (
	"net/http"
	"strconv"

	"financial-framework/database"
	"financial-framework/middleware"
)

func QuestionsPage(w http.ResponseWriter, r *http.Request) {
	err := r.ParseForm()
	if err != nil {
		return
	}

	//To check User authorized or not
	isAuthenticated := middleware.IsAuthenticated(r)

	JobBand := r.Form["JobBand"]
	JobFamily := r.Form["JobFamily"]

	family, err := database.GetJobFamilyById(JobFamily[0])

	i, err := strconv.Atoi(JobBand[0])
	if err != nil {
		// ... handle error
		panic(err)
	}
	band, err := database.GetJobBandById(i)

	questions, err := database.GetQuestionsForFamilyAndBand(*family, *band)
	if err != nil {
		return
	}

	m := map[string]interface{}{
		"family":          family,
		"band":            band,
		"questions":       questions,
		"isAuthenticated": isAuthenticated,
	}

	err = templates.ExecuteTemplate(w, "questions.html", m)
	if err != nil {
		return
	}
}
