package controllers

import (
	"fmt"
	"log"
	"net/http"

	"financial-framework/middleware"
)

const MaxUploadSize = 1024 * 1024 // 1MB

func AdminPage(w http.ResponseWriter, r *http.Request) {
	err := r.ParseForm()
	if err != nil {
		return
	}

	data := make(map[string]interface{})
	isAuthenticated := middleware.IsAuthenticated(r)
	data["isAuthenticated"] = isAuthenticated

	if isAuthenticated {
		err = templates.ExecuteTemplate(w, "admin.html", data)
		if err != nil {
			return
		}
	} else {
		http.Redirect(w, r, "/", http.StatusFound)
	}
}

func logLine(fieldName string, message string) string {
	log.Println(fmt.Sprintf("%s : %s", fieldName, message))
	return fmt.Sprintf("%s : %s \n", fieldName, message)
}
