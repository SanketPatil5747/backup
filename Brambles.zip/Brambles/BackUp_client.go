package database

import (
	"context"
	"encoding/json"
	"fmt"
	"log"

	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/config"
	"github.com/aws/aws-sdk-go-v2/service/secretsmanager"
	"github.com/aws/aws-secretsmanager-caching-go/secretcache"

	"gorm.io/driver/postgres"
	"gorm.io/gorm"

	"financial-framework/entities"
)

type AWSSecreteData struct {
	Host     string `json:"db_host"`
	Port     string `json:"db_port"`
	DBName   string `json:"db_name"`
	Username string `json:"db_username"`
	Password string `json:"db_password"`
}

var (
	Instance *gorm.DB
	err      error
	secrete  AWSSecreteData
)

func Connect(connectionString string) {
	log.Println(connectionString)
	Instance, err = gorm.Open(postgres.Open(connectionString), &gorm.Config{})
	if err != nil {
		log.Println(err)
		panic("Cannot connect to DB")
	}
	log.Println("Connected to Database...")
}

func Migrate() {
	err := Instance.AutoMigrate(&entities.JobFamily{}, &entities.JobBand{}, &entities.Question{}, &entities.Competency{}, &entities.Training{}, &entities.JobFunction{})
	if err != nil {
		log.Println(err)
		panic("Database Migration Failed")
	}
	log.Println("Database Migration Completed...")
}

func ConnectToAWS(aws_secretename string) {
	secretCache, err := secretcache.New()
	if err != nil {
		log.Println(err)
		panic("error initialising a SecretsManager Client")
	}

	result, err := secretCache.GetSecretString(aws_secretename)
	if err != nil {
		log.Println(err)
		panic("error getting a Secret String")
	}
	log.Println("Secrete ::", result)

	jsonerr := json.Unmarshal([]byte(result), &secrete)
	if jsonerr != nil {
		log.Println(jsonerr)
		panic("error unmarshaling a Secret String")
	}

	connectionString := fmt.Sprintf("host=%s port=%s user=%s password=%s dbname=%s sslmode=disable", secrete.Host, secrete.Port, secrete.Username, secrete.Password, secrete.DBName)
	log.Println(connectionString)

	Instance, err = gorm.Open(postgres.Open(connectionString), &gorm.Config{})
	if err != nil {
		log.Println(err)
		panic("Cannot connect to DB")
	}
	log.Println("Connected to Database...")
}

func LoadSecreteFromAWS() {
	aws_secretename := "brambles-financial-framework-secret"
	aws_region := "us-east-1"

	config, err := config.LoadDefaultConfig(context.TODO(), config.WithRegion(aws_region))
	if err != nil {
		log.Println(err)
	}

	// Create Secrets Manager client
	svc := secretsmanager.NewFromConfig(config)
	input := &secretsmanager.GetSecretValueInput{
		SecretId:     aws.String(aws_secretename),
		VersionStage: aws.String("AWSCURRENT"), // VersionStage defaults to AWSCURRENT if unspecified
	}

	result, err := svc.GetSecretValue(context.TODO(), input)
	if err != nil {
		log.Println(err.Error())
	}

	// Decrypts secret using the associated KMS key.
	var secretString string = *result.SecretString

	jsonerr := json.Unmarshal([]byte(secretString), &secrete)
	if jsonerr != nil {
		log.Println(jsonerr)
		panic("error unmarshaling a Secret String")
	}

	connectionString := fmt.Sprintf("host=%s port=%s user=%s password=%s dbname=%s sslmode=disable", secrete.Host, secrete.Port, secrete.Username, secrete.Password, secrete.DBName)
	log.Println(connectionString)

	Instance, err = gorm.Open(postgres.Open(connectionString), &gorm.Config{})
	if err != nil {
		log.Println(err)
		panic("Cannot connect to DB")
	}
	log.Println("Connected to Database...")
}
