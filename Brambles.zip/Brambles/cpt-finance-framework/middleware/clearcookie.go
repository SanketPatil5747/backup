package middleware

import (
	"net/http"
)

func InvalidateSessionHandler(w http.ResponseWriter, r *http.Request) {
	deleted := http.Cookie{
		Name:   "capability_session-0",
		Value:  "",
		Path:   "/",
		MaxAge: -1,
	}

	http.SetCookie(w, &deleted)
}
