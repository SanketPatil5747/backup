package main

import (
	"log"
	"os"

	"github.com/joho/godotenv"
)

type Config struct {
	Port          string `mapstructure:"port"`
	Client_ID     string `mapstructure:"client_id"`
	CLIENT_SECRET string `mapstructure:"client_secret"`
	ISSUER        string `mapstructure:"issuer"`
}

var AppConfig *Config
var ConnectionString string

func LoadAppConfig() {
	err := godotenv.Load()
	if err != nil {
		log.Fatalf("Error loading .env file")
	}

	//Server Information
	port := os.Getenv("PORT")
	if port == "" {
		port = "80"
	}

	//OKTA Details
	client_id := os.Getenv("CLIENT_ID")
	client_secret := os.Getenv("CLIENT_SECRET")
	issuer := os.Getenv("ISSUER")

	AppConfig = &Config{
		Port:          port,
		Client_ID:     client_id,
		CLIENT_SECRET: client_secret,
		ISSUER:        issuer,
	}
}
