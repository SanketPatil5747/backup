package main

import (
	"fmt"
	"html/template"
	"log"
	"net/http"
	"os"

	"github.com/gorilla/mux"

	"OKTA_GOLANG/controllers"
	"OKTA_GOLANG/middleware"
)

var templates *template.Template

func main() {
	// Load Configurations from config.json using Viper
	LoadAppConfig()

	middleware.GetOKTADetails(AppConfig.Client_ID,
		AppConfig.CLIENT_SECRET,
		AppConfig.ISSUER)

	// Initialize the router
	router := mux.NewRouter().StrictSlash(true)
	templates = template.Must(templates.ParseGlob("templates/*.html"))
	controllers.Init(templates)

	// Register Routes
	RegisterRoutes(router)

	// Start the server
	log.Println(fmt.Sprintf("Starting Server on port %s...", AppConfig.Port))

	hostname, err := os.Hostname()
	if err != nil {
		fmt.Println(err)
	}
	log.Printf("Running on Hostname: %s\n", hostname)

	log.Fatal(http.ListenAndServe(fmt.Sprintf("0.0.0.0:%v", AppConfig.Port), router))
}

func RegisterRoutes(router *mux.Router) {
	router.HandleFunc("/", controllers.IndexPage).Methods("GET")
	router.HandleFunc("/", controllers.IndexPage).Methods("POST")

	router.HandleFunc("/login", middleware.LoginHandler)
	router.HandleFunc("/authorization-code/callback", middleware.AuthCodeCallbackHandler)
	router.HandleFunc("/logout", middleware.LogoutHandler)

	router.PathPrefix("/static/").Handler(http.StripPrefix("/static/", http.FileServer(http.Dir("static/"))))

	http.Handle("/", router)
}
