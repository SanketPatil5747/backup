package controllers

import (
	"OKTA_GOLANG/middleware"
	"html/template"
	"net/http"
)

var templates *template.Template

func Init(t *template.Template) {
	templates = t
}

func IndexPage(w http.ResponseWriter, r *http.Request) {
	err := r.ParseForm()
	if err != nil {
		return
	}

	data := make(map[string]interface{})
	isAuthenticated := middleware.IsAuthenticated(r)

	data["isAuthenticated"] = isAuthenticated

	err = templates.ExecuteTemplate(w, "index.html", data)
	if err != nil {
		return
	}

}
